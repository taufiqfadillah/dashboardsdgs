<script src="<?= base_url(); ?>/assets/js/script.js"></script>

</body>

</html>